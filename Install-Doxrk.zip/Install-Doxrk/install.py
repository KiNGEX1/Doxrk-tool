import os
import time

print("      installing...")
time.sleep(3)
print("")

#setup
print("      Setting up files")
time.sleep(5)
os.system("mv /data/data/com.termux/files/home/Install-Doxrk/Doxrk /data/data/com.termux/files/usr/etc")
print("      Setting Doxrk file")
time.sleep(3)
os.system("mv /data/data/com.termux/files/home/Install-Doxrk/doxrk /data/data/com.termux/files/usr/bin")
print("Giving Permisions to start")
time.sleep(4)
os.system("chmod +x /data/data/com.termux/files/usr/bin/doxrk")
time.sleep(2)
print("Doxrk is installed you can run this tool by running the command 'doxrk' anytime anywhere")
os.system("rm -rf /data/data/com.termux/files/home/Install-Doxrk")
